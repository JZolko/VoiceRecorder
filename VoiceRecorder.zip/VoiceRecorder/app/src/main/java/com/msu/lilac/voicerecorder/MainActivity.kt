package com.msu.lilac.voicerecorder


import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val _soundRecorder = SoundRecorder(this)
    private var _isRecording = false
    val recordButton: Button by lazy { findViewById<Button>(R.id.RecordButton) }
    val stopButton: Button by lazy { findViewById<Button>(R.id.StopButton) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //login view

        // other login view

        // main audio record view
        //recordButton = findViewById<Button>(R.id.RecordButton)
        recordButton.setOnClickListener {
            if (!_isRecording) {
                _soundRecorder.startRecording()
                _isRecording = true
                //recordButton.text = "Recording"
            }
        }

        //stopButton = findViewById<Button>(R.id.StopButton)
        stopButton.setOnClickListener {
            _soundRecorder.stopRecording()
            _isRecording = false
            //stopButton.text = "Stopped"
            //recordButton.text = "Record"
        }
    }
}